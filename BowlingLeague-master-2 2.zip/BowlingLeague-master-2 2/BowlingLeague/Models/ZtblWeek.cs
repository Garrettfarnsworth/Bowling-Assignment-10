﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BowlingLeague.Models
{
    public partial class ZtblWeek
    {
        public byte[] WeekStart { get; set; }
        public byte[] WeekEnd { get; set; }
    }
}
