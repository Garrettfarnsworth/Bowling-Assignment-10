﻿using System;
using System.Collections.Generic;

#nullable disable

namespace BowlingLeague.Models
{
    public partial class ZtblSkipLabel
    {
        public long LabelCount { get; set; }
    }
}
